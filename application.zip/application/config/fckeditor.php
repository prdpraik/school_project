<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config = array(
'instanceName' => '',  
//BasePath is the location where the system will look for the fckeditor folder.
 'BasePath' => base_url().'template/plugins/fckeditor/', 
 'ToolbarSet' => 'Default',
 'Width' => '100%',
 'Height' => '300',
 'Value' => ''
              ); 
/* End of file fckeditor.php */
/* Location: ./application/config/fckeditor.php */